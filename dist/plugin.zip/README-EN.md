# Xiaohongshu

[中文](README.md) | [English](README-EN.md)

A Xiaohongshu media plugin for `res-downloader`. Plugin ID: `com.xiaohongshu.media`; version: `1.0.0`.

## Features

- Captures videos, single images and galleries from work detail responses after opening a work, without parsing the homepage recommendation feed in bulk.
- Downloads the highest usable video quality and merges separate video and AAC audio tracks into MP4.
- Groups each work into a collection, preserving image order and supporting individual or collection downloads.
- Adds a separate TXT caption child for preview and individual or collection downloads, preserving Unicode and line breaks.
- Saves each Live Photo image and its MP4 motion file as separate children.
- Preserves the title, author and publication time; uses the description's first line when the title is empty.
- Updates media URLs when reopening a work and suppresses scattered generic captures across the Xiaohongshu site and CDN.

## Installation

Once published, the plugin can be installed from Plugin Management in `res-downloader`. You can also download the source ZIP for the desired version and import it using the option to install from an archive.

## Settings

- **Enable logging**: off by default; records sanitized resource types, detail parsing failure reasons and caption capture stages, without captions or signed URLs.

## Notes

- Configure FFmpeg in the application for split-track video downloads. Progressive MP4 files, images and Live Photo motion files do not require merging.
- Video previews use a progressive MP4 with audio, potentially at a lower quality than downloads. A cover image is shown when no such rendition exists, if available.
- When separate audio is unavailable, the plugin falls back to a rendition with audio. If neither is available, it does not publish a downloadable video.
- Live Photos are exported as separate image and video files, not paired Apple Photos assets.
- Reopen the corresponding work when URLs expire. Refresh the page first if no new detail request is made. The plugin does not log in or request details proactively.
- Only the observed detail endpoint and media hosts are supported. Subtitles, DRM content and media on other CDNs are not supported.
- `xiaohongshu.com`, `xhscdn.com` and all their subdomains skip the generic detector, including avatars, homepage thumbnails, page assets, preloads and uncorrelated media. Other sites are unaffected; historical records are not removed.
- Failed detail extraction does not fall back to scattered generic captures. Enable logging to inspect detail parsing failure reasons.
- TXT captions are generated directly from captured work details, without page scripts. Empty captions or captions over 16384 characters are skipped rather than silently truncated.
- TXT files are stored in the application's capture cache. Reopen the work to recapture missing cache data.
- Split videos download the preview rendition as an extra temporary input; only the selected-quality merged video is saved as the output.

## Development and Validation

Run from the `res-downloader` project root:

```bash
node --check ./plugins/resd-plugin-xiaohongshu/main.js
go run main.go plugin lint ./plugins/resd-plugin-xiaohongshu
for fixturePath in ./plugins/resd-plugin-xiaohongshu/fixtures/*.json; do
  go run main.go plugin replay ./plugins/resd-plugin-xiaohongshu "$fixturePath" || break
done
go test ./plugins/resd-plugin-xiaohongshu/tests
go run main.go plugin pack ./plugins/resd-plugin-xiaohongshu
```

The package is written to `dist/plugin.zip`. All fixtures contain fictional, sanitized data. See the [development notes](tests/README.md) for endpoint scope, offline checks and manual acceptance steps.
